function calculateFee() {
    var studentType = document.getElementById("studentType").value;
    var residency = document.getElementById("residency").value;
    var credits = parseInt(document.getElementById("credits").value);
    var registrationFee;
    var tuitionRate;

    if (credits > 10) {
        alert("Maximum credits allowed is 10.");
        return;
    }

    if (studentType === "bachelor") {
        if (residency === "in-state") {
            registrationFee = 200;
            tuitionRate = 350;
        } else {
            registrationFee = 600;
            tuitionRate = 700;
        }
    } else {
        if (residency === "in-state") {
            registrationFee = 300;
            tuitionRate = 450;
        } else {
            registrationFee = 900;
            tuitionRate = 900;
        }
    }

    var tuition = tuitionRate * credits;
    var totalFee = registrationFee + tuition;

    var resultDiv = document.getElementById("result");

    resultDiv.innerHTML = 
        "<h3>Total Fee: $" + totalFee + "</h3>";

    var viewDetailsButton = document.createElement("button");
    viewDetailsButton.textContent = "View Details";
    viewDetailsButton.onclick = function () {
        viewitem(registrationFee, tuitionRate, tuition, totalFee);
    };
    resultDiv.appendChild(viewDetailsButton);

}


function viewitem(registrationFee, tuitionRate, tuition, totalFee) {
    var viewdetailsDiv = document.getElementById("result");
    viewdetailsDiv.innerHTML = `
        <h3>Registration Fee: $${registrationFee}</h3>
        <h3>Tuition Rate (per credit): $${tuitionRate}</h3>
        <h3>Tuition: $${tuition}</h3>
        <h3>Total Fee: $${totalFee}</h3>

        
    `;

} 
{/* <p>The registration fee is $200 for in-state bachelor student, 
$600 for out-state bachelor student, $300 for in-state master student, 
and $900 for out-state master student. 
The tuition rate (per credit) is $350 for in-state bachelor student, 
$700 for out-state bachelor student, $450 for in-state master student, 
and $900 for out-state master student.</p> */}
